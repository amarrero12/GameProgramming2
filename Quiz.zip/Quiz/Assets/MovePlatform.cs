﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePlatform : MonoBehaviour
{
    private Vector3 velocity;
    private float xPos, yPos;
    private float plusXpos, plusYpos;

    // Start is called before the first frame update
    void Start()
    {
        plusXpos = (2.0f * Mathf.PI) / 3.0f;
        plusYpos = (2.0f * Mathf.PI) / 1.3f;

    }

    // Update is called once per frame
    void Update()
    {

    }
}

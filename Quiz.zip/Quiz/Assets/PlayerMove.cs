﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    SpriteRenderer m_SpriteRenderer;
    Color m_NewColor;

    int speed = 10;

    void Start()
    {
        m_SpriteRenderer = GetComponent<SpriteRenderer>();
        //m_SpriteRenderer.color = Color.blue;
    }

    //private bool faceR = true;

    void Update () {

        float vert = Input.GetAxis ("Vertical")*speed;
        float horz = Input.GetAxis ("Horizontal")*speed;

        vert *= Time.deltaTime;
        horz *= Time.deltaTime;

        transform.Translate(horz, vert, 0);

    //    if (faceR == false && horz > 0)
    //    {
    //        Flip();
    //    }
    //    else if (faceR == true && horz < 0)
    //    {
    //        Flip();
    //    }
    }

    //void Flip()
    //{
    //    faceR = !faceR;
    //    Vector3 Scaler = transform.localScale;
    //    Scaler.x *= -1;
    //    transform.localScale = Scaler;
    //}

    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "rojo")
        {
            Debug.Log(other.gameObject.tag);
            m_SpriteRenderer.color = Color.red;
        }
        if (other.gameObject.tag == "azulito")
        {
            Debug.Log(other.gameObject.tag);
            m_SpriteRenderer.color = Color.cyan;
        }
        if (other.gameObject.tag == "negrito")
        {
            Debug.Log(other.gameObject.tag);
            m_SpriteRenderer.color = Color.black;
        }
        if (other.gameObject.tag == "gris")
        {
            Debug.Log(other.gameObject.tag);
            m_SpriteRenderer.color = Color.gray;
        }
        if (other.gameObject.tag == "verde")
        {
            Debug.Log(other.gameObject.tag);
            m_SpriteRenderer.color = Color.green;
        }
        if (other.gameObject.tag == "blanco")
        {
            Debug.Log(other.gameObject.tag);
            m_SpriteRenderer.color = Color.white;
        }
        if (other.gameObject.tag == "magentica")
        {
            Debug.Log(other.gameObject.tag);
            m_SpriteRenderer.color = Color.magenta;
        }
        if (other.gameObject.tag == "amarillo")
        {
            Debug.Log(other.gameObject.tag);
            m_SpriteRenderer.color = Color.yellow;
        }
        if (other.gameObject.tag == "azul")
        {
            Debug.Log(other.gameObject.tag);
            m_SpriteRenderer.color = Color.blue;
        }
    }

}
